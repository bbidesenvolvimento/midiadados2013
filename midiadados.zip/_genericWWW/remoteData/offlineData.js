var offlineData =
{

    "mercadoDemografia":[
    {
        "titulo": "A FORMAÇÃO UNIVERSITÁRIA DE PUBLICIDADE NO BRASIL",
        "link": "/images/midiaDados/offline/mercadoDemografia/1.png",
        "ad": ""
    },
    {
        "titulo": "ESTASTÍSTICAS POPULACIONAL E PROJEÇÃO DE DOMICÍLIOS OCUPADOS (MIL) - ESTADOS",
        "link": "/images/midiaDados/offline/mercadoDemografia/2.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DA POPULAÇÃO E DOMICÍLIOS OCUPADOS (MIL)",
        "link": "/images/midiaDados/offline/mercadoDemografia/3.png",
        "ad": ""
    },
    {
        "titulo": "ESTATÍSTICA POPULACIONAL E PROJEÇÃO DE DOMICÍLIOS OCUPADOS (MIL) - CAPITAIS",
        "link": "/images/midiaDados/offline/mercadoDemografia/4.png",
        "ad": ""
    },
    {
        "titulo": "POPULAÇÃO BRASILEIRA FAIXA ETÁRIA",
        "link": "/images/midiaDados/offline/mercadoDemografia/5.png",
        "ad": ""
    },
    {
        "titulo": "POPULAÇÃO BRASILEIRA",
        "link": "/images/midiaDados/offline/mercadoDemografia/6.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO PRODUTO INTERNO BRUTO TOTAL E PER CAPITA 2000 A 2012",
        "link": "/images/midiaDados/offline/mercadoDemografia/7.png",
        "ad": ""
    },
    {
        "titulo": "PRODUTO INTERNO BRUTO POR ESTADO 2009/ 2010",
        "link": "/images/midiaDados/offline/mercadoDemografia/8.png",
        "ad": ""
    },
    {
        "titulo": "ÍNDICE DE POTENCIAL DE CONSUMO X POPULAÇÃO DAS REGIÕES",
        "link": "/images/midiaDados/offline/mercadoDemografia/9.png",
        "ad": ""
    },
    {
        "titulo": "ÍNDICE DE POTENCIAL DE CONSUMO X POPULAÇÃO DOS ESTADOS BRASILEIROS",
        "link": "/images/midiaDados/offline/mercadoDemografia/10.png",
        "ad": ""
    },
    {
        "titulo": "PROJEÇÕES PARA ÁREAS NIELSEN - 2013",
        "link": "/images/midiaDados/offline/mercadoDemografia/11.png",
        "ad": ""
    },
    {
        "titulo": "PROJEÇÕES PARA ÁREAS IBOPE - 2013",
        "link": "/images/midiaDados/offline/mercadoDemografia/12.png",
        "ad": ""
    },
    {
        "titulo": "POTENCIAL DE CONSUMO TOTAL BRASIL - 2012",
        "link": "/images/midiaDados/offline/mercadoDemografia/13.png",
        "ad": ""
    },
    {
        "titulo": "POTENCIAL DE CONSUMO POR CLASSE",
        "link": "/images/midiaDados/offline/mercadoDemografia/14.png",
        "ad": ""
    },
    {
        "titulo": "A INDÚSTRIA DA COMUNICAÇÃO NO BRASIL",
        "link": "/images/midiaDados/offline/mercadoDemografia/15.png",
        "ad": ""
    },
    {
        "titulo": "INVESTIMENTO EM MÍDIA NO BRASIL E PARTICIPAÇÃO DE CADA MEIO - INTER-MEIOS",
        "link": "/images/midiaDados/offline/mercadoDemografia/16.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DO INVESTIMENTO BRUTO EM MÍDIA POR MEIO",
        "link": "/images/midiaDados/offline/mercadoDemografia/17.png",
        "ad": ""
    },
    {
        "titulo": "FATURAMENTO BRUTO MENSAL DE MÍDIA POR MEIO - INTER-MEIOS - 2012 (%)",
        "link": "/images/midiaDados/offline/mercadoDemografia/18.png",
        "ad": ""
    },
    {
        "titulo": "DISTRIBUIÇÃO DO FATURAMENTO BRUTO POR REGIÃO INTER-MEIOS 2012",
        "link": "/images/midiaDados/offline/mercadoDemografia/19.png",
        "ad": ""
    },
    {
        "titulo": "RANKING: 50 MAIORES AGÊNCIAS",
        "link": "/images/midiaDados/offline/mercadoDemografia/20.png",
        "ad": ""
    },
    {
        "titulo": "CONTA DIVIDIDA - ANUNCIANTES, PRODUTOS E AGÊNCIAS",
        "link": "/images/midiaDados/offline/mercadoDemografia/21.png",
        "ad": ""
    },
    {
        "titulo": "INVESTIMENTO PUBLICITÁRIO TOTAL POR SETOR ECONÔMICO",
        "link": "/images/midiaDados/offline/mercadoDemografia/22.png",
        "ad": ""
    },
    {
        "titulo": "INVESTIMENTO PUBLICITÁRIO POR SETOR ECONÔMICO POR MEIO",
        "link": "/images/midiaDados/offline/mercadoDemografia/23.png",
        "ad": ""
    },
    {
        "titulo": "MAIORES ANUNCIANTES - MERCADO",
        "link": "/images/midiaDados/offline/mercadoDemografia/24.png",
        "ad": ""
    },
    {
        "titulo": "30 MAIORES ANUNCIANTES POR MEIO",
        "link": "/images/midiaDados/offline/mercadoDemografia/25.png",
        "ad": ""
    },
    {
        "titulo": "PROJEÇÃO DE RENDA MÉDIA MENSAL POR CLASSE ECONÔMICA",
        "link": "/images/midiaDados/offline/mercadoDemografia/26.png",
        "ad": ""
    },
    {
        "titulo": "CLASSIFICAÇÃO ECONÔMICA",
        "link": "/images/midiaDados/offline/mercadoDemografia/27.png",
        "ad": ""
    },
    {
        "titulo": "PARTICIPAÇÃO DE CADA MEIO - IBOPE MONITOR",
        "link": "/images/midiaDados/offline/mercadoDemografia/28.png",
        "ad": ""
    }],
    "adHoc":[
    {
        "titulo": "DATA FAVELA - DISTRIBUIÇÃO E NÍVEL DE ENSINO NAS COMUNIDADES",
        "link": "/images/midiaDados/offline/adHoc/1.png",
        "ad": ""
    },
    {
        "titulo": "DATA FAVELA - PERFIL DE BENS E COMPRA",
        "link": "/images/midiaDados/offline/adHoc/2.png",
        "ad": ""
    },
    {
        "titulo": "ALIMENTAÇÃO",
        "link": "/images/midiaDados/offline/adHoc/3.png",
        "ad": ""
    },
    {
        "titulo": "AUTONOMIA e COMPRAS",
        "link": "/images/midiaDados/offline/adHoc/4.png",
        "ad": ""
    },
    {
        "titulo": "GADGETS e ATITUDE",
        "link": "/images/midiaDados/offline/adHoc/5.png",
        "ad": ""
    },
    {
        "titulo": "PERSONAGENS",
        "link": "/images/midiaDados/offline/adHoc/6.png",
        "ad": ""
    }],
    "televisao":[
    {
        "titulo": "PERFIL DEMOGRÁFICO, PENETRAÇÃO E EVOLUÇÃO DA PENETRAÇÃO NO MEIO",
        "link": "/images/midiaDados/offline/televisao/1.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DOS DOMICÍLIOS COM TV",
        "link": "/images/midiaDados/offline/televisao/2.png",
        "ad": ""
    },
    {
        "titulo": "PROJEÇÃO DOS DOMICÍLIOS COM TV",
        "link": "/images/midiaDados/offline/televisao/3.png",
        "ad": ""
    },
    {
        "titulo": "VENDAS INDUSTRIAIS DE APARELHOS DE TV E VÍDEO/APARELHOS EM USO E NÚMERO DE EMISSORAS COMERCIAIS POR REDE",
        "link": "/images/midiaDados/offline/televisao/4.png",
        "ad": ""
    },
    {
        "titulo": "COBERTURA GEOGRÁFICA DE TV E EVOLUÇÃO DO SHARE NACIONAL DAS REDES",
        "link": "/images/midiaDados/offline/televisao/5.png",
        "ad": ""
    },
    {
        "titulo": "POPULAÇÃO E DOMICÍLIOS COM TV - ÁREAS METROPOLITANAS",
        "link": "/images/midiaDados/offline/televisao/6.png",
        "ad": ""
    },
    {
        "titulo": "TOTAL DE DOMICÍLIOS COM TELEVISORES LIGADOS",
        "link": "/images/midiaDados/offline/televisao/7.png",
        "ad": ""
    },
    {
        "titulo": "PARTICIPAÇÃO DA AUDIÊNCIA DAS REDES",
        "link": "/images/midiaDados/offline/televisao/8.png",
        "ad": ""
    },
    {
        "titulo": "COMPOSIÇÃO DA PROGRAMAÇÃO",
        "link": "/images/midiaDados/offline/televisao/9.png",
        "ad": ""
    },
    {
        "titulo": "AÇÕES DE MERCHANDISING NA TV",
        "link": "/images/midiaDados/offline/televisao/10.png",
        "ad": ""
    },
    {
        "titulo": "CANAIS INDEPENDENTES - PERFIL DEMOGRÁFICO",
        "link": "/images/midiaDados/offline/televisao/11.png",
        "ad": ""
    }],
    "tvAssinatura":[
    {
        "titulo": "PERFIL, PENETRAÇÃO E EVOLUÇÃO DA PENETRAÇÃO DO MEIO",
        "link": "/images/midiaDados/offline/tvAssinatura/1.png",
        "ad": ""
    },
    {
        "titulo": "MUDANÇAS NO PERFIL DO MEIO",
        "link": "/images/midiaDados/offline/tvAssinatura/2.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DO NÚMERO DE DOMICÍLIOS ASSINANTES e ASSINANTES POR TECNOLOGIA",
        "link": "/images/midiaDados/offline/tvAssinatura/3.png",
        "ad": ""
    },
    {
        "titulo": "CURVA DE AUDIÊNCIA DO PÚBLICO ASSINANTE DE TV POR ASSINATURA: ASSISTE A TV ABERTA X TV POR ASSINATURA POR PERÍODO",
        "link": "/images/midiaDados/offline/tvAssinatura/4.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DA PENETRAÇÃO - TV ASSINATURA e EXPOSIÇÃO A OUTROS MEIOS DO PÚBLICO ASSINANTE DE TV POR ASSINATURA x NÃO ASSINANTES",
        "link": "/images/midiaDados/offline/tvAssinatura/5.png",
        "ad": ""
    },
    {
        "titulo": "GUIA DE CANAIS POR GÊNERO",
        "link": "/images/midiaDados/offline/tvAssinatura/6.png",
        "ad": ""
    },
    {
        "titulo": "ALCANCE PRINCIPAIS CANAIS TV ASSINATURA",
        "link": "/images/midiaDados/offline/tvAssinatura/7.png",
        "ad": ""
    }],
    "radio":[
    {
        "titulo": "EVOLUÇÃO DOS DOMICÍLIOS COM RÁDIO",
        "link": "/images/midiaDados/offline/radio/1.png",
        "ad": ""
    },
    {
        "titulo": "PROJEÇÃO DE DOMICÍLIOS COM RÁDIO - 2012",
        "link": "/images/midiaDados/offline/radio/2.png",
        "ad": ""
    },
    {
        "titulo": "PERFIL DO CONSUMIDORES DO MEIO",
        "link": "/images/midiaDados/offline/radio/3.png",
        "ad": ""
    },
    {
        "titulo": "COBERTURA DOS PRINCIPAIS MERCADOS",
        "link": "/images/midiaDados/offline/radio/4.png",
        "ad": ""
    },
    {
        "titulo": "PENETRAÇÃO POR SEXO, CLASSE E IDADE",
        "link": "/images/midiaDados/offline/radio/5.png",
        "ad": ""
    },
    {
        "titulo": "PENETRAÇÃO DE RÁDIO AM FM",
        "link": "/images/midiaDados/offline/radio/6.png",
        "ad": ""
    },
    {
        "titulo": "TOTAL DE EMISSORAS DE RÁDIO EXISTENTES NO BRASIL",
        "link": "/images/midiaDados/offline/radio/7.png",
        "ad": ""
    },
    {
        "titulo": "TOTAL DE EMISSORAS DE RÁDIO",
        "link": "/images/midiaDados/offline/radio/8.png",
        "ad": ""
    },
    {
        "titulo": "POPULAÇÃO POTENCIAL DO RÁDIO - ÁREAS METROPOLITANAS",
        "link": "/images/midiaDados/offline/radio/9.png",
        "ad": ""
    },
    {
        "titulo": "AUDIÊNCIA POR FAIXA HORÁRIA",
        "link": "/images/midiaDados/offline/radio/10.png",
        "ad": ""
    }],
    "revista":[
    {
        "titulo": "PERFIL E PENETRAÇÃO DO MEIO - REVISTA",
        "link": "/images/midiaDados/offline/revista/1.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DA CIRCULAÇÃO DOS PRINCIPAIS TÍTULOS",
        "link": "/images/midiaDados/offline/revista/2.png",
        "ad": ""
    },
    {
        "titulo": "EDIÇÕES ESPECIAIS E ANUÁRIOS - CIRCULAÇÃO",
        "link": "/images/midiaDados/offline/revista/3.png",
        "ad": ""
    },
    {
        "titulo": "REVISTAS SEGMENTADAS ASSOCIADAS À ANATEC",
        "link": "/images/midiaDados/offline/revista/4.png",
        "ad": ""
    },
    {
        "titulo": "DISTRIBUIÇÃO GEOGRÁFICA",
        "link": "/images/midiaDados/offline/revista/5.png",
        "ad": ""
    },
    {
        "titulo": "DISTRIBUIÇÃO DE REVISTAS POR REGIÃO x IPC x POPULAÇÃO",
        "link": "/images/midiaDados/offline/revista/6.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DA CIRCULAÇÃO BRASIL DOS TÍTULOS FILIADOS AO IVC",
        "link": "/images/midiaDados/offline/revista/7.png",
        "ad": ""
    },
    {
        "titulo": "CADERNOS REGIONAIS",
        "link": "/images/midiaDados/offline/revista/8.png",
        "ad": ""
    },
    {
        "titulo": "TÍTULOS DE REVISTAS POR GÊNERO VENDIDOS EM BANCAS E ASSINATURAS E TÍTULOS DAS PRINCIPAIS EDITORAS",
        "link": "/images/midiaDados/offline/revista/9.png",
        "ad": ""
    }],
    "jornal":[
    {
        "titulo": "PERFIL E PENETRAÇÃO DOS CONSUMIDORES DO MEIO",
        "link": "/images/midiaDados/offline/jornal/1.png",
        "ad": ""
    },
    {
        "titulo": "DIAS DE LEITURA JORNAL",
        "link": "/images/midiaDados/offline/jornal/2.png",
        "ad": ""
    },
    {
        "titulo": "CIRCULAÇÃO DE TÍTULOS FILIADOS AO IVC",
        "link": "/images/midiaDados/offline/jornal/3.png",
        "ad": ""
    },
    {
        "titulo": "JORNAIS DE DISTRIBUIÇÃO GRATUITA",
        "link": "/images/midiaDados/offline/jornal/4.png",
        "ad": ""
    },
    {
        "titulo": "TÍTULOS DE JORNAL - POR REGIÃO E ESTADO",
        "link": "/images/midiaDados/offline/jornal/5.png",
        "ad": ""
    },
    {
        "titulo": "DISTRIBUIÇÃO DE JORNAIS POR REGIÃO X IPC X POPULAÇÃO",
        "link": "/images/midiaDados/offline/jornal/6.png",
        "ad": ""
    },
    {
        "titulo": "JORNAIS DE BAIRRO DE SÃO PAULO",
        "link": "/images/midiaDados/offline/jornal/7.png",
        "ad": ""
    },
    {
        "titulo": "CIRCULAÇÃO DE REVISTAS ENCARTADAS EM JORNAIS",
        "link": "/images/midiaDados/offline/jornal/8.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DA CIRCULAÇÃO - TÍTULOS FILIADOS AO IVC",
        "link": "/images/midiaDados/offline/jornal/9.png",
        "ad": ""
    },
    {
        "titulo": "SEÇÕES, CADERNOS E TABLÓIDES",
        "link": "/images/midiaDados/offline/jornal/10.png",
        "ad": ""
    }],
    "entretenimento":[
    {
        "titulo": "NÚMERO DE CINEMAS QUE EXIBEM PUBLICIDADE",
        "link": "/images/midiaDados/offline/entretenimento/1.png",
        "ad": ""
    },
    {
        "titulo": "PERFIL DOS CONSUMIDORES - CINEMA",
        "link": "/images/midiaDados/offline/entretenimento/2.png",
        "ad": ""
    },
    {
        "titulo": "PENETRAÇÃO POR SEXO, CLASSE E IDADE - CINEMA",
        "link": "/images/midiaDados/offline/entretenimento/3.png",
        "ad": ""
    },
    {
        "titulo": "BILHETERIAS – CINEMA NACIONAL",
        "link": "/images/midiaDados/offline/entretenimento/4.png",
        "ad": ""
    },
    {
        "titulo": "BILHETERIAS - CINEMA",
        "link": "/images/midiaDados/offline/entretenimento/5.png",
        "ad": ""
    },
    {
        "titulo": "RANKING DE FILMES NACIONAIS 2000 – 2012 (POR PÚBLICO)",
        "link": "/images/midiaDados/offline/entretenimento/6.png",
        "ad": ""
    },
    {
        "titulo": "MAIORES BILHETERIAS",
        "link": "/images/midiaDados/offline/entretenimento/7.png",
        "ad": ""
    }],
    "midiaOutHome":[
    {
        "titulo": "PERFIL DEMOGRÁFICO E PENETRAÇÃO",
        "link": "/images/midiaDados/offline/midiaOutHome/1.png",
        "ad": ""
    },
    {
        "titulo": "COBERTURA DE OUT-OF-HOME EM UMA SEMANA POR TIPO DE SUPORTE/CLASSE ECONÔMICA",
        "link": "/images/midiaDados/offline/midiaOutHome/2.png",
        "ad": ""
    },
    {
        "titulo": "COBERTURA DE OUT-OF-HOME EM UMA SEMANA POR TIPO DE SUPORTE/ MERCADO",
        "link": "/images/midiaDados/offline/midiaOutHome/3.png",
        "ad": ""
    },
    {
        "titulo": "NÚMEROS DE LOCAIS/ CARTAZES POR ESTADO/ CAPITAIS",
        "link": "/images/midiaDados/offline/midiaOutHome/4.png",
        "ad": ""
    },
    {
        "titulo": "NÚMERO DE LOCAIS / CARTAZES DOS 40 PRINCIPAIS MUNICÍPIOS DO BRASIL - EXCETO CAPITAIS - BASE IPC",
        "link": "/images/midiaDados/offline/midiaOutHome/5.png",
        "ad": ""
    },
    {
        "titulo": "PENETRAÇÃO DOOH",
        "link": "/images/midiaDados/offline/midiaOutHome/6.png",
        "ad": ""
    },
    {
        "titulo": "NOTOU DOOH POR SUPORTE E POR MIX DE MEIOS",
        "link": "/images/midiaDados/offline/midiaOutHome/7.png",
        "ad": ""
    },
    {
        "titulo": "SEGMENTAÇÃO DOOH - QUEM SÃO ELES",
        "link": "/images/midiaDados/offline/midiaOutHome/8.png",
        "ad": ""
    },
    {
        "titulo": "SEGMENTAÇÃO DOOH",
        "link": "/images/midiaDados/offline/midiaOutHome/9.png",
        "ad": ""
    },
    {
        "titulo": "PERFIL DOS CONSUMIDORES",
        "link": "/images/midiaDados/offline/midiaOutHome/10.png",
        "ad": ""
    }],
    "midiaDigital":[
    {
        "titulo": "OS MAIORES USUÁRIOS DE INTERNET DO MUNDO e NÚMERO DE INTERNAUTA POR GRANDES REGIÕES",
        "link": "/images/midiaDados/offline/midiaDigital/1.png",
        "ad": ""
    },
    {
        "titulo": "PERFIL E PENETRAÇÃO DO INTERNAUTA BRASILEIRO",
        "link": "/images/midiaDados/offline/midiaDigital/2.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DA PENETRAÇÃO DE INTERNET POR MERCADO E ACESSO À INTERNET ULT 3 DIAS POR MERCADO",
        "link": "/images/midiaDados/offline/midiaDigital/3.png",
        "ad": ""
    },
    {
        "titulo": "INTERNAUTAS NA POPULAÇÃO - 2012",
        "link": "/images/midiaDados/offline/midiaDigital/4.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DOS DADOS GERAIS DE INTERNET - JANEIRO 2001 a JANEIRO 2013",
        "link": "/images/midiaDados/offline/midiaDigital/5.png",
        "ad": ""
    },
    {
        "titulo": "EVOLUÇÃO DO ACESSO À INTERNET E EVOLUÇÃO DO PERFIL DO INTERNAUTA",
        "link": "/images/midiaDados/offline/midiaDigital/6.png",
        "ad": ""
    },
    {
        "titulo": "ACSSO À INTERNET NO BRASIL",
        "link": "/images/midiaDados/offline/midiaDigital/7.png",
        "ad": ""
    },
    {
        "titulo": "AUDIÊNCIA E ALCANCE POR CATEGORIA DE SITE EM RESIDÊNCIAS E NO TRABALHO",
        "link": "/images/midiaDados/offline/midiaDigital/8.png",
        "ad": ""
    },
    {
        "titulo": "ALCANCE POR CATEGORIA DO SITE",
        "link": "/images/midiaDados/offline/midiaDigital/9.png",
        "ad": ""
    },
    {
        "titulo": "PERFIL DEMOGRÁFICO",
        "link": "/images/midiaDados/offline/midiaDigital/10.png",
        "ad": ""
    },
    {
        "titulo": "RANKING MUNDIAL - SEGMENTOS",
        "link": "/images/midiaDados/offline/midiaDigital/11.png",
        "ad": ""
    },
    {
        "titulo": "MÍDIAS SOCIAIS - SITES DE RELACIONAMENTO SOCIAL",
        "link": "/images/midiaDados/offline/midiaDigital/12.png",
        "ad": ""
    },
    {
        "titulo": "TV SOCIAL",
        "link": "/images/midiaDados/offline/midiaDigital/13.png",
        "ad": ""
    },
    {
        "titulo": "MOBILE",
        "link": "/images/midiaDados/offline/midiaDigital/14.png",
        "ad": ""
    }],
    "custoMidia":[
    {
        "titulo": "EVOLUÇÃO DOS CUSTOS DE MÍDIA (%)",
        "link": "/images/midiaDados/offline/custoMidia/1.png",
        "ad": ""
    },
    {
        "titulo": "ÍNDICE DE EVOLUÇÃO DOS CUSTOS DE MÍDIA (%)",
        "link": "/images/midiaDados/offline/custoMidia/2.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE TELEVISÃO - NACIONAL",
        "link": "/images/midiaDados/offline/custoMidia/3.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE TELEVISÃO - PARTICIPAÇÃO",
        "link": "/images/midiaDados/offline/custoMidia/4.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE RÁDIO",
        "link": "/images/midiaDados/offline/custoMidia/5.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE REVISTAS – PRINCIPAIS TÍTULOS DE CADA SEGMENTO",
        "link": "/images/midiaDados/offline/custoMidia/6.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE JORNAIS",
        "link": "/images/midiaDados/offline/custoMidia/7.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE OUTDOOR",
        "link": "/images/midiaDados/offline/custoMidia/8.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE CINEMA",
        "link": "/images/midiaDados/offline/custoMidia/9.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE TV POR ASSINATURA",
        "link": "/images/midiaDados/offline/custoMidia/10.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE INDOOR",
        "link": "/images/midiaDados/offline/custoMidia/11.png",
        "ad": ""
    },
    {
        "titulo": "CUSTOS DE INDOOR ELEMIDIA",
        "link": "/images/midiaDados/offline/custoMidia/12.png",
        "ad": ""
    }],
    "americaLatina":[
    {
        "titulo": "INVESTIMENTO EM PROPAGANDA",
        "link": "/images/midiaDados/offline/americaLatina/1.png",
        "ad": ""
    },
    {
        "titulo": "AMÉRICA LATINA",
        "link": "/images/midiaDados/offline/americaLatina/2.png",
        "ad": ""
    },
    {
        "titulo": "AUMENTO DOS CUSTOS DE MÍDIA (%)",
        "link": "/images/midiaDados/offline/americaLatina/3.png",
        "ad": ""
    },
    {
        "titulo": "INVESTIMENTO PUBLICITÁRIO POR MEIO",
        "link": "/images/midiaDados/offline/americaLatina/4.png",
        "ad": ""
    },
    {
        "titulo": "MAIORES AGÊNCIAS POR INVESTIMENTO",
        "link": "/images/midiaDados/offline/americaLatina/5.png",
        "ad": ""
    },
    {
        "titulo": "MAIORES ANUNCIANTES",
        "link": "/images/midiaDados/offline/americaLatina/6.png",
        "ad": ""
    },
    {
        "titulo": "MEIOS DE COMUNICAÇÃO - TV",
        "link": "/images/midiaDados/offline/americaLatina/7.png",
        "ad": ""
    },
    {
        "titulo": "TV POR ASSINATURA - ASSINANTES BRASIL",
        "link": "/images/midiaDados/offline/americaLatina/8.png",
        "ad": ""
    },
    {
        "titulo": "TVS POR ASSINATURA – PRINCIPAIS CANAIS BRASIL",
        "link": "/images/midiaDados/offline/americaLatina/9.png",
        "ad": ""
    },
    {
        "titulo": "TV POR ASSINATURA – ASSINANTES AMÉRICA LATINA",
        "link": "/images/midiaDados/offline/americaLatina/10.png",
        "ad": ""
    },
    {
        "titulo": "TVS POR ASSINATURA - PRINCIPAIS CANAIS",
        "link": "/images/midiaDados/offline/americaLatina/11.png",
        "ad": ""
    },
    {
        "titulo": "TV POR ASSINATURA - ARGENTINA",
        "link": "/images/midiaDados/offline/americaLatina/12.png",
        "ad": ""
    },
    {
        "titulo": "RÁDIO",
        "link": "/images/midiaDados/offline/americaLatina/13.png",
        "ad": ""
    },
    {
        "titulo": "REVISTA",
        "link": "/images/midiaDados/offline/americaLatina/14.png",
        "ad": ""
    },
    {
        "titulo": "JORNAL",
        "link": "/images/midiaDados/offline/americaLatina/15.png",
        "ad": ""
    },
    {
        "titulo": "CINEMA - BRASIL",
        "link": "/images/midiaDados/offline/americaLatina/16.png",
        "ad": ""
    },
    {
        "titulo": "CINEMA & OUT OF HOME - AMÉRICA LATINA",
        "link": "/images/midiaDados/offline/americaLatina/17.png",
        "ad": ""
    },
    {
        "titulo": "OUT OF HOME - BRASIL",
        "link": "/images/midiaDados/offline/americaLatina/18.png",
        "ad": ""
    },
    {
        "titulo": "INTERNET",
        "link": "/images/midiaDados/offline/americaLatina/19.png",
        "ad": ""
    }],
    "midiaInternacional":
    [{
        "titulo": "INVESTIMENTO EM PROPAGANDA NO MUNDO",
        "link": "/images/midiaDados/offline/midiaInternacional/1.png",
        "ad": ""
    },
    {
        "titulo": "INVESTIMENTO EM PROPAGANDA TOP 25",
        "link": "/images/midiaDados/offline/midiaInternacional/2.png",
        "ad": ""
    },
    {
        "titulo": "DISTRIBUIÇÃO DE VERBA DE MÍDIA TOP 25",
        "link": "/images/midiaDados/offline/midiaInternacional/3.png",
        "ad": ""
    },
    {
        "titulo": "INVESTIMENTO PUBLICITÁRIO POR MEIO",
        "link": "/images/midiaDados/offline/midiaInternacional/4.png",
        "ad": ""
    }]
   /* "mercadoDemografia": [
        {
            "titulo": "Estatísticas populacional e projeção de domicílios ocupados (mil) - estados!!!",
            "link": "/images/midiaDados/offline/mercadoDemografia/1.jpg",
            "ad": ""
        }
    ],
    "pesquisaMidia": [
        {
            "titulo": "Pesquisa de mídia 1",
            "link": "#",
            "ad": ""
        },
        {
            "titulo": "Pesquisa de mídia 2",
            "link": "#",
            "ad": ""
        },
        {
            "titulo": "Pesquisa de mídia 3",
            "link": "#",
            "ad": ""
        },
        {
            "titulo": "Pesquisa de mídia 4",
            "link": "#",
            "ad": ""
        },
        {
            "titulo": "Pesquisa de mídia 5",
            "link": "#",
            "ad": ""
        }
    ],
    "adHoc": [
        {
            "titulo": "Pesquisa Ad-Hoc 1",
            "link": "/images/midiaDados/offline/adHoc/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Pesquisa Ad-Hoc 2",
            "link": "/images/midiaDados/offline/adHoc/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Pesquisa Ad-Hoc 3",
            "link": "/images/midiaDados/offline/adHoc/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Pesquisa Ad-Hoc 4",
            "link": "/images/midiaDados/offline/adHoc/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Pesquisa Ad-Hoc 5",
            "link": "/images/midiaDados/offline/adHoc/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Pesquisa Ad-Hoc 6",
            "link": "/images/midiaDados/offline/adHoc/5.jpg",
            "ad": ""
        }
    ],
    "televisao": [
        {
            "titulo": "Televisão 1",
            "link": "/images/midiaDados/offline/televisao/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 2",
            "link": "/images/midiaDados/offline/televisao/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 3",
            "link": "/images/midiaDados/offline/televisao/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 4",
            "link": "/images/midiaDados/offline/televisao/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 5",
            "link": "/images/midiaDados/offline/televisao/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 6",
            "link": "/images/midiaDados/offline/televisao/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 7",
            "link": "/images/midiaDados/offline/televisao/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 8",
            "link": "/images/midiaDados/offline/televisao/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 9",
            "link": "/images/midiaDados/offline/televisao/9.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 10",
            "link": "/images/midiaDados/offline/televisao/10.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão 11",
            "link": "/images/midiaDados/offline/televisao/11.jpg",
            "ad": ""
        }
    ],
    "tvAssinatura": [
        {
            "titulo": "Televisão Por Assinatura 1",
            "link": "/images/midiaDados/offline/tvAssinatura/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão Por Assinatura 2",
            "link": "/images/midiaDados/offline/tvAssinatura/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão Por Assinatura 3",
            "link": "/images/midiaDados/offline/tvAssinatura/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão Por Assinatura 4",
            "link": "/images/midiaDados/offline/tvAssinatura/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Televisão Por Assinatura 5",
            "link": "/images/midiaDados/offline/tvAssinatura/5.jpg",
            "ad": ""
        }
    ],
    "radio": [
        {
            "titulo": "Rádio 1",
            "link": "/images/midiaDados/offline/radio/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 2",
            "link": "/images/midiaDados/offline/radio/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 3",
            "link": "/images/midiaDados/offline/radio/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 4",
            "link": "/images/midiaDados/offline/radio/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 5",
            "link": "/images/midiaDados/offline/radio/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 6",
            "link": "/images/midiaDados/offline/radio/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 7",
            "link": "/images/midiaDados/offline/radio/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 8",
            "link": "/images/midiaDados/offline/radio/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Rádio 9",
            "link": "/images/midiaDados/offline/radio/9.jpg",
            "ad": ""
        }
    ],
    "revista": [
        {
            "titulo": "Revista 1",
            "link": "/images/midiaDados/offline/revista/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 2",
            "link": "/images/midiaDados/offline/revista/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 3",
            "link": "/images/midiaDados/offline/revista/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 4",
            "link": "/images/midiaDados/offline/revista/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 5",
            "link": "/images/midiaDados/offline/revista/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 6",
            "link": "/images/midiaDados/offline/revista/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 7",
            "link": "/images/midiaDados/offline/revista/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 8",
            "link": "/images/midiaDados/offline/revista/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Revista 9",
            "link": "/images/midiaDados/offline/revista/9.jpg",
            "ad": ""
        }

    ],

    "jornal": [
        {
            "titulo": "Jornal 1",
            "link": "/images/midiaDados/offline/jornal/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 2",
            "link": "/images/midiaDados/offline/jornal/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 3",
            "link": "/images/midiaDados/offline/jornal/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 4",
            "link": "/images/midiaDados/offline/jornal/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 5",
            "link": "/images/midiaDados/offline/jornal/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 6",
            "link": "/images/midiaDados/offline/jornal/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 7",
            "link": "/images/midiaDados/offline/jornal/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 8",
            "link": "/images/midiaDados/offline/jornal/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 9",
            "link": "/images/midiaDados/offline/jornal/9.jpg",
            "ad": ""
        },
        {
            "titulo": "Jornal 10",
            "link": "/images/midiaDados/offline/jornal/10.jpg",
            "ad": ""
        }
    ],
    "entretenimento": [
        {
            "titulo": "Entretenimento 1",
            "link": "/images/midiaDados/offline/entretenimento/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Entretenimento 2",
            "link": "/images/midiaDados/offline/entretenimento/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Entretenimento 3",
            "link": "/images/midiaDados/offline/entretenimento/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Entretenimento 4",
            "link": "/images/midiaDados/offline/entretenimento/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Entretenimento 5",
            "link": "/images/midiaDados/offline/entretenimento/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Entretenimento 6",
            "link": "/images/midiaDados/offline/entretenimento/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Entretenimento 7",
            "link": "/images/midiaDados/offline/entretenimento/7.jpg",
            "ad": ""
        }
    ],
    "midiaOutHome": [
        {
            "titulo": "Mídia Out Home 1",
            "link": "/images/midiaDados/offline/midiaOutHome/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 2",
            "link": "/images/midiaDados/offline/midiaOutHome/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 3",
            "link": "/images/midiaDados/offline/midiaOutHome/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 4",
            "link": "/images/midiaDados/offline/midiaOutHome/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 5",
            "link": "/images/midiaDados/offline/midiaOutHome/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 6",
            "link": "/images/midiaDados/offline/midiaOutHome/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 7",
            "link": "/images/midiaDados/offline/midiaOutHome/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 8",
            "link": "/images/midiaDados/offline/midiaOutHome/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 9",
            "link": "/images/midiaDados/offline/midiaOutHome/9.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Out Home 10",
            "link": "/images/midiaDados/offline/midiaOutHome/10.jpg",
            "ad": ""
        }
    ],
    "midiaDigital": [
        {
            "titulo": "Mídia Digital 1",
            "link": "/images/midiaDados/offline/midiaDigital/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 2",
            "link": "/images/midiaDados/offline/midiaDigital/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 3",
            "link": "/images/midiaDados/offline/midiaDigital/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 4",
            "link": "/images/midiaDados/offline/midiaDigital/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 5",
            "link": "/images/midiaDados/offline/midiaDigital/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 6",
            "link": "/images/midiaDados/offline/midiaDigital/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 7",
            "link": "/images/midiaDados/offline/midiaDigital/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 8",
            "link": "/images/midiaDados/offline/midiaDigital/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 9",
            "link": "/images/midiaDados/offline/midiaDigital/9.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 10",
            "link": "/images/midiaDados/offline/midiaDigital/10.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 11",
            "link": "/images/midiaDados/offline/midiaDigital/11.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 12",
            "link": "/images/midiaDados/offline/midiaDigital/12.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 13",
            "link": "/images/midiaDados/offline/midiaDigital/13.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Digital 14",
            "link": "/images/midiaDados/offline/midiaDigital/14.jpg",
            "ad": ""
        }
    ],
    "custoMidia": [
        {
            "titulo": "Custo de Mídia 1",
            "link": "/images/midiaDados/offline/custoMidia/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 2",
            "link": "/images/midiaDados/offline/custoMidia/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 3",
            "link": "/images/midiaDados/offline/custoMidia/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 4",
            "link": "/images/midiaDados/offline/custoMidia/4.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 5",
            "link": "/images/midiaDados/offline/custoMidia/5.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 6",
            "link": "/images/midiaDados/offline/custoMidia/6.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 7",
            "link": "/images/midiaDados/offline/custoMidia/7.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 8",
            "link": "/images/midiaDados/offline/custoMidia/8.jpg",
            "ad": ""
        },
        {
            "titulo": "Custo de Mídia 9",
            "link": "/images/midiaDados/offline/custoMidia/9.jpg",
            "ad": ""
        }
    ],
    "americaLatina": [
        {
            "titulo": "América Latina 1",
            "link": "/images/midiaDados/offline/americaLatina/1.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 2",
            "link": "/images/midiaDados/offline/americaLatina/2.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 3",
            "link": "/images/midiaDados/offline/americaLatina/3.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 4",
            "link": "/images/midiaDados/offline/americaLatina/4.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 5",
            "link": "/images/midiaDados/offline/americaLatina/5.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 6",
            "link": "/images/midiaDados/offline/americaLatina/6.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 7",
            "link": "/images/midiaDados/offline/americaLatina/7.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 8",
            "link": "/images/midiaDados/offline/americaLatina/8.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 9",
            "link": "/images/midiaDados/offline/americaLatina/9.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 10",
            "link": "/images/midiaDados/offline/americaLatina/10.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 11",
            "link": "/images/midiaDados/offline/americaLatina/11.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 12",
            "link": "/images/midiaDados/offline/americaLatina/12.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 13",
            "link": "/images/midiaDados/offline/americaLatina/13.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 14",
            "link": "/images/midiaDados/offline/americaLatina/14.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 15",
            "link": "/images/midiaDados/offline/americaLatina/15.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 16",
            "link": "/images/midiaDados/offline/americaLatina/16.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 17",
            "link": "/images/midiaDados/offline/americaLatina/17.jpg",
            "ad": ""
        },
        {
            "titulo": "América Latina 18",
            "link": "/images/midiaDados/offline/americaLatina/18.jpg",
            "ad": ""
        }
    ],
    "midiaInternacional": [
        {
            "titulo": "Mídia Internacional 1",
            "link": "/images/midiaDados/offline/midiaInternacional/1.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Internacional 2",
            "link": "/images/midiaDados/offline/midiaInternacional/2.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Internacional 3",
            "link": "/images/midiaDados/offline/midiaInternacional/3.jpg",
            "ad": ""
        },
        {
            "titulo": "Mídia Internacional  4",
            "link": "/images/midiaDados/offline/midiaInternacional/4.jpg",
            "ad": ""
        }
    ]*/
};
