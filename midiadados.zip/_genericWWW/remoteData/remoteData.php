<?php
/**
 * Created by IntelliJ IDEA.
 * User: filiperp
 * Date: 29/04/13
 * Time: 01:30
 * To change this template use File | Settings | File Templates.
 */
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');

echo  '{
    "mercadoDemografia": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário Para testes de títulos longos",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "pesquisaMidia": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "adHoc": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "televisao": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "tvAssinatura": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios"  ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "radio": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "revista": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento",
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],

    "jornal": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases"  ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras"   ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento"  ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento"    ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "entretenimento": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases"       ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios"      ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "midiaOutHome": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "midiaDigital": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "custoMidia": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "americaLatina": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras"  ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ],
    "midiaInternacional": [
        {
            "titulo": "Informações sobre o mundo",
            "link": "http://public.tableausoftware.com/views/Galeria_Pases/DashPases" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Relatório de Investimento Publicitário",
            "link": "https://public.tableausoftware.com/views/Modelo_Intermeios/Intermeios"   ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Perfil das Cidades Brasileiras",
            "link": "https://public.tableausoftware.com/views/Galeria_Perfil/Perfildascidadesbrasileiras" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Evolução de Investimento",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento" ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        },
        {
            "titulo": "Lorem Ipsum Dolor",
            "link": "https://public.tableausoftware.com/views/Galeria_Monitor/EvoluodeInvestimento"   ,
            "ad" : "http://2.bp.blogspot.com/-iLjeAkDVstg/UVi43yk5QiI/AAAAAAAAKT0/NmcQBPzxF8w/s1600/owl-orly.jpg"
        }
    ]
}';

?>

